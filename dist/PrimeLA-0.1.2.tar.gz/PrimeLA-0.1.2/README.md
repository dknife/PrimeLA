#PrimeLA
### Visualization Package for 'Prime Linear Algebra'
### '으뜸 선형대수'를 위한 가시화 패키지

This is a simple preliminary package 
for visualizing the vectors (2d and 3d) and matrix (2x2, 3x3)

[GitHub Repository](https://github.com/dknife/PrimeLA)

Author: Young-Min Kang (c) 2021

